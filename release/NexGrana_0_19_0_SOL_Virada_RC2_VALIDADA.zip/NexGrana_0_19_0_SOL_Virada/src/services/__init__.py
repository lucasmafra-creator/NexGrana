"""Serviços independentes da interface."""
